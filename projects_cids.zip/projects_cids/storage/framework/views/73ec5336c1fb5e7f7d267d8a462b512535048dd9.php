<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 15%;
  height: 100%; 
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 16px 15px;
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ddd;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 16px 16px;
  border: 1px solid #ccc;
  width: 85%;
  height: 100%;
}
</style>

<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    	margin-left: auto;
    	margin-right: auto;

		}
		#emp td,#emp th{
			border: 0px;
			padding: 10px,10px;
      vertical-align:top;
      font-size: 14px;
      text-align: left;
		}
        /* Style the tab */
.tab2,.tab6 {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab6 button,.tab4 button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab6 button:hover {
  background-color: #ccc;
}

/* Create an active/current tablink class */
.tab6 button.active {
  background-color: #ccc;
}

.tabcontent6 {
  animation: fadeEffect 1s;
  display: none;
  padding: 12px 18px;
  border: 1px solid #ccc;
  border-top: none;
}
@keyframes  fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
.tab6 select.split {
  float: right;
  background-color: #04AA6D;
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}
	</style>
    <style>
  * {box-sizing: border-box;}

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #E1B355;
  }

  .topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #E1B355;
    color: white;
  }

  .topnav a.active {
    background-color: #2196F3;
    color: white;
  }

  .topnav .search-container {
    float: right;
  }

  .topnav input[type=text] {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
  }

  .topnav .search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 16px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
  }

  .topnav .search-container button:hover {
    background: #ccc;
  }

  @media  screen and (max-width: 600px) {
    .topnav .search-container {
      float: none;
    }
    .topnav a, .topnav input[type=text], .topnav .search-container button {
      float: none;
      display: block;
      text-align: left;
      width: 100%;
      margin: 0;
      padding: 14px;
    }
    .topnav input[type=text] {
      border: 1px solid #ccc;  
    }
  }
  </style>
</head>
<body>

<strong id="emp">Vice Mayorial Elections  (<?php echo e(request('year')); ?>)</strong>          
<div class="tab6">
  <button class="tablinks6" onclick="openCity6(event, 'Luzon6')" id="defaultOpen6">Luzon</button>
  <button class="tablinks6" onclick="openCity6(event, 'NCR6')">NCR</button>
  <button class="tablinks6" onclick="openCity6(event, 'Visayas6')">Visayas</button>
  <button class="tablinks6" onclick="openCity6(event, 'Mindanao6')">Mindanao</button>
  
</div> 

<div id="Luzon6" class="tabcontent6">
<table id="emp">
<tbody>
<tr>
    <td><strong>Ilocos Region</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Ilocos Region")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br></td>
    <td><strong>Cagayan Valley</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Cagayan Valley")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br></td>
    <td><strong>CAR</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "CAR")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <br></td>
    <td><strong>Central Luzon</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Central Luzon")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    <br></td>      
    <td><strong>CALABARZON</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "CALABARZON")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br></td>
    <td><strong>MIMAROPA</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "MIMAROPA")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <br></td>      
    <td><strong>Bicol Region</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Bicol Region")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
  </td>
	</tr>
</tbody>
</table>
</div>


<div id="NCR6" class="tabcontent6">
<table  id="emp">
<tbody>
    <td>
    <td><strong>NCR</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "NCR")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
</td>
</tbody>
</table>
</div>

<div id="Visayas6" class="tabcontent6">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Western Visayas</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Western Visayas")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
    <td><strong>Central Visayas</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Central Visayas")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
    <td><strong>Eastern Visayas</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Eastern Visayas")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  </td>
    	</tr>
</tbody>
</table>
</div>

<div id="Mindanao6" class="tabcontent6">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Zamboanga Peninsula</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Zamboanga Peninsula")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
    <td><strong>Northern Mindanao</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Northern Mindanao")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
    <td><strong>Davao Region</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "Davao Region")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
    <td><strong>SOCCSKSARGEN</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "SOCCSKSARGEN")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
    <td><strong>CARAGA</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "CARAGA")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
    <td><strong>BARMM</strong><br>
    <?php $__currentLoopData = $navs2->where('rid', "BARMM")->where('position',"Vice Mayorial"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="<?php echo e(route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Mayorial'])); ?>"><?php echo e($emps->city); ?></a></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  <br></td>
	</tr> 
</tbody>
</table>
</div>

<div class="grid grid-cols-1 md:grid-cols-2">
<div class="p-6">
  <small>Luzon Gender Demographics of Candidates </small>
  <canvas id="myChart19" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues19 = ['Male (<?php echo e($elec19); ?>)', 'Female (<?php echo e($elec20); ?>)']; // Labels for the bars
    const yValues19 = [<?php echo e($elec19); ?>, <?php echo e($elec20); ?>]; // Values for the bars

    const barColors19 = "#00cc99";

    new Chart("myChart19", {
        type: "horizontalBar",
        data: {
            labels: xValues19,
            datasets: [{
                backgroundColor: barColors19,
                data: yValues19
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Luzon Gender Demographics of Winning Candidates </small>
  <canvas id="myChart20" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues20 = ['Male (<?php echo e($winning_elec19); ?>)', 'Female (<?php echo e($winning_elec20); ?>)']; // Labels for the bars
    const yValues20 = [<?php echo e($winning_elec19); ?>, <?php echo e($winning_elec20); ?>];

    const barColors20 = "#00cc99";

    new Chart("myChart20", {
        type: "horizontalBar",
        data: {
            labels: xValues20,
            datasets: [{
                backgroundColor: barColors20,
                data: yValues20
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Visayas Gender Demographics of Candidates </small>
  <canvas id="myChart21" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues21 = ['Male (<?php echo e($elec21); ?>)', 'Female (<?php echo e($elec22); ?>)']; // Labels for the bars
    const yValues21 = [<?php echo e($elec21); ?>, <?php echo e($elec22); ?>]; // Values for the bars

    const barColors21 = "#00cc99";

    new Chart("myChart21", {
        type: "horizontalBar",
        data: {
            labels: xValues21,
            datasets: [{
                backgroundColor: barColors21,
                data: yValues21
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Visayas Gender Demographics of Winning Candidates </small>
  <canvas id="myChart22" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues22 = ['Male (<?php echo e($winning_elec21); ?>)', 'Female (<?php echo e($winning_elec22); ?>)']; // Labels for the bars
    const yValues22 = [<?php echo e($winning_elec21); ?>, <?php echo e($winning_elec22); ?>];

    const barColors22 = "#00cc99";

    new Chart("myChart22", {
        type: "horizontalBar",
        data: {
            labels: xValues22,
            datasets: [{
                backgroundColor: barColors22,
                data: yValues22
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Mindanao Gender Demographics of Candidates </small>
  <canvas id="myChart23" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues23 = ['Male (<?php echo e($elec23); ?>)', 'Female (<?php echo e($elec24); ?>)']; // Labels for the bars
    const yValues23 = [<?php echo e($elec23); ?>, <?php echo e($elec24); ?>]; // Values for the bars

    const barColors23 = "#00cc99";

    new Chart("myChart23", {
        type: "horizontalBar",
        data: {
            labels: xValues23,
            datasets: [{
                backgroundColor: barColors23,
                data: yValues23
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Mindanao Gender Demographics of Winning Candidates </small>
  <canvas id="myChart24" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues24 = ['Male (<?php echo e($winning_elec23); ?>)', 'Female (<?php echo e($winning_elec24); ?>)']; // Labels for the bars
    const yValues24 = [<?php echo e($winning_elec23); ?>, <?php echo e($winning_elec24); ?>]; // Values for the bars

    const barColors24 = "#00cc99";

    new Chart("myChart24", {
        type: "horizontalBar",
        data: {
            labels: xValues24,
            datasets: [{
                backgroundColor: barColors24,
                data: yValues24
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
    </div>
</div>
</div>


<script>
function openPosition(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script>
function openCity6(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent6");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks6");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen6").click();
</script>
   
</body>
</html><?php /**PATH /home/ucc/export-import/resources/views/navs6.blade.php ENDPATH**/ ?>