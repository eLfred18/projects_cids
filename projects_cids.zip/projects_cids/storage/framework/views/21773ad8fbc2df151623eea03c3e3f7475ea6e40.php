<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 15%;
  height: 100%; 
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 16px 15px;
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ddd;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 16px 16px;
  border: 1px solid #ccc;
  width: 85%;
  height: 100%;
}
</style>

<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    	margin-left: auto;
    	margin-right: auto;

		}
		#emp td,#emp th{
			border: 0px;
			padding: 10px,10px;
      vertical-align:top;
      font-size: 14px;
      text-align: left;
		}
        /* Style the tab */
.tab2,.tab4 {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab2 button,.tab4 button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab2 button:hover {
  background-color: #ccc;
}

/* Create an active/current tablink class */
.tab2 button.active {
  background-color: #ccc;
}

.tabcontent2 {
  animation: fadeEffect 1s;
  display: none;
  padding: 12px 18px;
  border: 1px solid #ccc;
  border-top: none;
}
@keyframes  fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
.tab2 select.split {
  float: right;
  background-color: #04AA6D;
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}
	</style>
    <style>
  * {box-sizing: border-box;}

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #E1B355;
  }

  .topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #E1B355;
    color: white;
  }

  .topnav a.active {
    background-color: #2196F3;
    color: white;
  }

  .topnav .search-container {
    float: right;
  }

  .topnav input[type=text] {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
  }

  .topnav .search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 16px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
  }

  .topnav .search-container button:hover {
    background: #ccc;
  }

  @media  screen and (max-width: 600px) {
    .topnav .search-container {
      float: none;
    }
    .topnav a, .topnav input[type=text], .topnav .search-container button {
      float: none;
      display: block;
      text-align: left;
      width: 100%;
      margin: 0;
      padding: 14px;
    }
    .topnav input[type=text] {
      border: 1px solid #ccc;  
    }
  }
  .text-gray-500{--text-opacity:1;color:#a0aec0;color:rgba(160,174,192,var(--text-opacity))}
  </style>
</head>
<body>
 <!-- header -->
<div class="topnav">
  <a href="#" disabled><strong>Philippine Local Government Interactive Dataset</strong></a>
  <div class="search-container">
    <form action="<?php echo e(url('searchResults')); ?>" method="GET">
      <input type="text" placeholder="Search by candidate name... " name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
</div>

 <!-- vertical menu -->

<div class="tab">
  <button class="tablinks" onclick="openPosition(event, 'gov')" id="defaultOpen">Gubernatorial</button>
  <button class="tablinks" onclick="openPosition(event, 'vgov')">Vice Gubernatorial</button>
  <button class="tablinks" onclick="openPosition(event, 'may')">Mayorial</button>
  <button class="tablinks" onclick="openPosition(event, 'vmay')">Vice Mayorial</button>
  <a href="http://127.0.0.1:8000/export"><button class="tablinks">Download Election Dataset</button></a>
  <a href="http://127.0.0.1:8000/import-form" target="_blank"><button class="tablinks">Import Election Dataset</button></a>
  <a href="http://127.0.0.1:8000/import-performance" target="_blank"><button class="tablinks">Import Data</button></a>
</div>

<div id="gov" class="tabcontent">
 <!-- Content for the right column Gubernatorial-->
 <div class="page">
 <?php echo $__env->make('navs2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<div id="vgov" class="tabcontent">
<!-- Content for the right column Vice Gubernatorial-->
 <div class="page">
 <?php echo $__env->make('navs3', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<div id="may" class="tabcontent">
 <!-- Content for the right column Mayorial-->
 <div class="page">
 <?php echo $__env->make('navs4', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<div id="vmay" class="tabcontent">
 <!-- Content for the right column Vice Mayorial-->
 <div class="page">
 <?php echo $__env->make('navs6', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>  
</div>

<script>
function openPosition(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script>
function openCity2(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent2");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks2");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen2").click();
</script>

<script>
function openCity4(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent4");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks4");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen4").click();
</script>
   

                    <div class="text-center text-sm text-gray-500 sm:text-left">
                       <small>&nbsp;&nbsp;&copy; UP CIDS (PSPC) 2024</small>
                    </div>
</body>
</html><?php /**PATH /home/ucc/export-import/resources/views/navs.blade.php ENDPATH**/ ?>