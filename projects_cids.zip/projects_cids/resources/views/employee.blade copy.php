<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
	<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 80%;
    		margin-left: auto;
    		margin-right: auto;

		}
		#emp td,#emp th{
			border: 1px solid #ddd;
			padding: 8px;
		}
		#emp tr:nth-child(even){
            background-color: #e4f0f0;

		}
		#emp th{
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: left;
			background-color: #4CAF50;
			color: #fff;
		}
	</style>
</head>
<body>
<p id="emp"> <p>
<div id="emp">

</div>

<div id="emp" style="display: flex;">
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the left column -->
           
<canvas id="myChart" style="width:100%;max-width:100%"></canvas>
<script>
    const xValues = [];
    const yValues = [];

    @foreach($employees->where('city', "Alaminos City") as $emp)
        xValues.push("{{$emp->candidate}} ({{$emp->party}})");
        yValues.push({{$emp->votes}});
    @endforeach

    const barColors = "#00cc99";

    new Chart("myChart", {
        type: "horizontalBar",
        data: {
            labels: xValues,
            datasets: [{
                backgroundColor: barColors,
                data: yValues
            }]
        },
        options: {
            legend: { display: false },
            title: {
                display: true,
                text: "Region 1: Alaminos City (2013)"
            }
        }
    });
</script>
        </div>
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the right column -->
            
<canvas id="myChart2" style="width:100%;max-width:100%"></canvas>
<script>
    const labels = [];
    const data = [];
    const backgroundColors = [];

    @foreach($employees->where('city', "Alaminos City") as $emp)
        labels.push("{{$emp->candidate}} ({{$emp->party}})");
        data.push({{$emp->votes}});
        backgroundColors.push("#" + ((1 << 24) * Math.random() | 0).toString(16)); // Random color generation
    @endforeach

    new Chart("myChart2", {
        type: "pie",
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: backgroundColors
            }]
        },
        options: {
            title: {
                display: true,
                text: "Region 1: Alaminos City (2013)"
            }
        }
    });
</script>
        </div>
    </div>



	<table id="emp">
		<thead>
			<tr>
				<th>Candidates</th>
				<th>Gender</th>
				<th>Party</th>
				<th>Votes</th>
				
			</tr>
		</thead>
		<tbody>
			@foreach($employees->where('city', "Alaminos City") as $emp)
               <tr>
                <td>{{$emp->candidate}}</td>
                <td>{{$emp->gender==1? 'Male':'Female'}}</td>
                <td>{{$emp->party}}</td>
                <td>{{$emp->votes}}</td>

               </tr>
			@endforeach
		</tbody>
	</table>

</body>
</html>