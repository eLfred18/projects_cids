<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    		margin-left: auto;
    		margin-right: auto;

		}
		#emp td,#emp th{
			border: 1px solid #ddd;
			padding: 12px;
		}
		#emp tr:nth-child(even){
            background-color: #e4f0f0;

		}
		#emp th{
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: left;
			background-color: #4CAF50;
			color: #fff;
		}
	</style>

<style>
  * {box-sizing: border-box;}

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #E1B355;
  }

  .topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #E1B355;
    color: white;
  }

  .topnav a.active {
    background-color: #2196F3;
    color: white;
  }

  .topnav .search-container {
    float: right;
  }

  .topnav input[type=text] {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
  }

  .topnav .search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 16px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
  }

  .topnav .search-container button:hover {
    background: #ccc;
  }

  @media screen and (max-width: 600px) {
    .topnav .search-container {
      float: none;
    }
    .topnav a, .topnav input[type=text], .topnav .search-container button {
      float: none;
      display: block;
      text-align: left;
      width: 100%;
      margin: 0;
      padding: 14px;
    }
    .topnav input[type=text] {
      border: 1px solid #ccc;  
    }
  }
  .text-gray-500{--text-opacity:1;color:#a0aec0;color:rgba(160,174,192,var(--text-opacity))}
  </style>
</head>
<body><!-- header -->
  <div class="topnav">
  <a href="#" disabled><strong>Philippine Local Government Interactive Dataset</strong></a>
  <div class="search-container">
    <form action="{{ url('searchResults') }}" method="GET">
      <input type="text" placeholder="Search by candidate name... " name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
  </div>
  </div>  


</div>

<div id="emp" style="display: flex;">
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the left column -->
           
<table id="emp">
<thead>
<tr>
    <th>Candidates</th>
    <th>Region</th>
    <th>City/Province</th>
    <th>Position</th>
    <th>Election Year</th>
    <th>Result</th>
    
</tr>
</thead>
<tbody>
@foreach($candi2->where('candidate',request('candidate')) as $emp)
   <tr>
    <td>{{$emp->candidate}}</td>
    <td>{{$emp->rid}}</td>
    <td>{{$emp->city}}</td>
    <td>{{$emp->position}}</td>
    <td>{{$emp->year}}</td>
    <td>{{$emp->won? 'Elected':''}}</td>

    </tr>
@endforeach
</tbody>
</table>
</div>
    </div>



    <div class="flex justify-center mt-4 sm:items-center sm:justify-between">
                    <div class="text-center text-sm text-gray-500 sm:text-left">
                       <small>&nbsp;&nbsp;&copy; UP CIDS (PSPC) 2024</small>
                    </div></div>

	

</body>
</html>