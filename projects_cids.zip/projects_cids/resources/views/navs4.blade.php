<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 15%;
  height: 100%; 
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 16px 15px;
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ddd;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 16px 16px;
  border: 1px solid #ccc;
  width: 85%;
  height: 100%;
}
</style>

<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    	margin-left: auto;
    	margin-right: auto;

		}
		#emp td,#emp th{
			border: 0px;
			padding: 10px,10px;
      vertical-align:top;
      font-size: 14px;
      text-align: left;
		}
        /* Style the tab */
.tab2,.tab5 {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab5 button,.tab4 button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab5 button:hover {
  background-color: #ccc;
}

/* Create an active/current tablink class */
.tab5 button.active {
  background-color: #ccc;
}

.tabcontent5 {
  animation: fadeEffect 1s;
  display: none;
  padding: 12px 18px;
  border: 1px solid #ccc;
  border-top: none;
}
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
.tab5 select.split {
  float: right;
  background-color: #04AA6D;
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}
	</style>
    <style>
  * {box-sizing: border-box;}

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #E1B355;
  }

  .topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #E1B355;
    color: white;
  }

  .topnav a.active {
    background-color: #2196F3;
    color: white;
  }

  .topnav .search-container {
    float: right;
  }

  .topnav input[type=text] {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
  }

  .topnav .search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 16px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
  }

  .topnav .search-container button:hover {
    background: #ccc;
  }

  @media screen and (max-width: 600px) {
    .topnav .search-container {
      float: none;
    }
    .topnav a, .topnav input[type=text], .topnav .search-container button {
      float: none;
      display: block;
      text-align: left;
      width: 100%;
      margin: 0;
      padding: 14px;
    }
    .topnav input[type=text] {
      border: 1px solid #ccc;  
    }
  }
  </style>
</head>
<body>

<strong id="emp">Mayorial Elections  ({{request('year')}})</strong>          
<div class="tab5">
  <button class="tablinks5" onclick="openCity5(event, 'Luzon5')" id="defaultOpen5">Luzon</button>
  <button class="tablinks5" onclick="openCity5(event, 'NCR5')">NCR</button>
  <button class="tablinks5" onclick="openCity5(event, 'Visayas5')">Visayas</button>
  <button class="tablinks5" onclick="openCity5(event, 'Mindanao5')">Mindanao</button>
  
</div> 

<div id="Luzon5" class="tabcontent5">
<table id="emp">
<tbody>
<tr>
    <td><strong>Ilocos Region</strong><br>
    @foreach($navs2->where('rid', "Ilocos Region")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>Cagayan Valley</strong><br>
    @foreach($navs2->where('rid', "Cagayan Valley")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>CAR</strong><br>
    @foreach($navs2->where('rid', "CAR")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
    <br></td>
    <td><strong>Central Luzon</strong><br>
    @foreach($navs2->where('rid', "Central Luzon")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
    <br></td>      
    <td><strong>CALABARZON</strong><br>
    @foreach($navs2->where('rid', "CALABARZON")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>MIMAROPA</strong><br>
    @foreach($navs2->where('rid', "MIMAROPA")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>      
    <td><strong>Bicol Region</strong><br>
    @foreach($navs2->where('rid', "Bicol Region")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
  </td>
	</tr>
</tbody>
</table>

<div class="grid grid-cols-1 md:grid-cols-2">
    <div class="p-6">
        <small>Luzon Gender Demographics of Candidates </small>
        <canvas id="myChart7" style="width:90%;max-width:90%;height:50%;"></canvas>
        <script>
            const xValues7 = ['Male ({{$elec13}})', 'Female ({{$elec14}})']; // Labels for the bars
            const yValues7 = [{{$elec13}}, {{$elec14}}]; // Values for the bars

            const barColors7 = "#00cc99";

            new Chart("myChart7", {
                type: "horizontalBar",
                data: {
                    labels: xValues7,
                    datasets: [{
                        backgroundColor: barColors7,
                        data: yValues7
                    }]
                },
                options: {
                    plugins: {
                        datalabels: {
                            anchor: 'end',
                            align: 'end',
                            formatter: function(value, context) {
                                return value; // Display the value as label
                            }
                        }
                    },
                    legend: { display: false },
                    title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
                }
            });
        </script>
    </div>

    <div class="p-6">
        <small>Luzon Gender Demographics of Winning Candidates </small>
        <canvas id="myChart8" style="width:90%;max-width:90%;height:50%;"></canvas>
        <script>
            const xValues8 = ['Male ({{$winning_elec13}})', 'Female ({{$winning_elec14}})']; // Labels for the bars
            const yValues8 = [{{$winning_elec13}}, {{$winning_elec14}}];

            const barColors8 = "#00cc99";

            new Chart("myChart8", {
                type: "horizontalBar",
                data: {
                    labels: xValues8,
                    datasets: [{
                        backgroundColor: barColors8,
                        data: yValues8
                    }]
                },
                options: {
                    plugins: {
                        datalabels: {
                            anchor: 'end',
                            align: 'end',
                            formatter: function(value, context) {
                                return value; // Display the value as label
                            }
                        }
                    },
                    legend: { display: false },
                    title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
                }
            });
        </script>
    </div>
</div>
</div>


<div id="NCR5" class="tabcontent5">
<table  id="emp">
<tbody>
    <td>
    <td><strong>NCR</strong><br>
    @foreach($navs2->where('rid', "NCR")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
</td>
</tbody>
</table>

<div class="grid grid-cols-1 md:grid-cols-2">
    <div class="p-6">
        <small>NCR Gender Demographics of Candidates </small>
        <canvas id="myChart25" style="width:90%;max-width:90%;height:50%;"></canvas>
        <script>
            const xValues25 = ['Male ({{$elec25}})', 'Female ({{$elec26}})']; // Labels for the bars
            const yValues25 = [{{$elec25}}, {{$elec26}}]; // Values for the bars

            const barColors25 = "#00cc99";

            new Chart("myChart25", {
                type: "horizontalBar",
                data: {
                    labels: xValues25,
                    datasets: [{
                        backgroundColor: barColors25,
                        data: yValues25
                    }]
                },
                options: {
                    plugins: {
                        datalabels: {
                            anchor: 'end',
                            align: 'end',
                            formatter: function(value, context) {
                                return value; // Display the value as label
                            }
                        }
                    },
                    legend: { display: false },
                    title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
                }
            });
        </script>
    </div>

    <div class="p-6">
        <small>NCR Gender Demographics of Winning Candidates </small>
        <canvas id="myChart26" style="width:90%;max-width:90%;height:50%;"></canvas>
        <script>
            const xValues26 = ['Male ({{$winning_elec25}})', 'Female ({{$winning_elec26}})']; // Labels for the bars
            const yValues26 = [{{$winning_elec25}}, {{$winning_elec26}}];

            const barColors26 = "#00cc99";

            new Chart("myChart26", {
                type: "horizontalBar",
                data: {
                    labels: xValues26,
                    datasets: [{
                        backgroundColor: barColors26,
                        data: yValues26
                    }]
                },
                options: {
                    plugins: {
                        datalabels: {
                            anchor: 'end',
                            align: 'end',
                            formatter: function(value, context) {
                                return value; // Display the value as label
                            }
                        }
                    },
                    legend: { display: false },
                    title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
                }
            });
        </script>
    </div>
</div>
</div>

<div id="Visayas5" class="tabcontent5">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Western Visayas</strong><br>
    @foreach($navs2->where('rid', "Western Visayas")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    <td><strong>Central Visayas</strong><br>
    @foreach($navs2->where('rid', "Central Visayas")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Eastern Visayas")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    	</tr>
</tbody>
</table>

<div class="grid grid-cols-1 md:grid-cols-2">
<div class="p-6">
  <small>Visayas Gender Demographics of Candidates </small>
  <canvas id="myChart9" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues9 = ['Male ({{$elec15}})', 'Female ({{$elec16}})']; // Labels for the bars
    const yValues9 = [{{$elec15}}, {{$elec16}}]; // Values for the bars

    const barColors9 = "#00cc99";

    new Chart("myChart9", {
        type: "horizontalBar",
        data: {
            labels: xValues9,
            datasets: [{
                backgroundColor: barColors9,
                data: yValues9
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Visayas Gender Demographics of Winning Candidates </small>
  <canvas id="myChart10" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues10 = ['Male ({{$winning_elec15}})', 'Female ({{$winning_elec16}})']; // Labels for the bars
    const yValues10 = [{{$winning_elec15}}, {{$winning_elec16}}];

    const barColors10 = "#00cc99";

    new Chart("myChart10", {
        type: "horizontalBar",
        data: {
            labels: xValues10,
            datasets: [{
                backgroundColor: barColors10,
                data: yValues10
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
        }
    });
  </script>
</div>
</div>
</div>

<div id="Mindanao5" class="tabcontent5">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Zamboanga Peninsula</strong><br>
    @foreach($navs2->where('rid', "Zamboanga Peninsula")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>Northern Mindanao</strong><br>
    @foreach($navs2->where('rid', "Northern Mindanao")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>Davao Region</strong><br>
    @foreach($navs2->where('rid', "Davao Region")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>SOCCSKSARGEN</strong><br>
    @foreach($navs2->where('rid', "SOCCSKSARGEN")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>CARAGA</strong><br>
    @foreach($navs2->where('rid', "CARAGA")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>BARMM</strong><br>
    @foreach($navs2->where('rid', "BARMM")->where('position',"Mayorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Mayorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
	</tr> 
</tbody>
</table>

<div class="grid grid-cols-1 md:grid-cols-2">
<div class="p-6">
  <small>Mindanao Gender Demographics of Candidates </small>
  <canvas id="myChart11" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues11 = ['Male ({{$elec17}})', 'Female ({{$elec18}})']; // Labels for the bars
    const yValues11 = [{{$elec17}}, {{$elec18}}]; // Values for the bars

    const barColors11 = "#00cc99";

    new Chart("myChart11", {
        type: "horizontalBar",
        data: {
            labels: xValues11,
            datasets: [{
                backgroundColor: barColors11,
                data: yValues11
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Mindanao Gender Demographics of Winning Candidates </small>
  <canvas id="myChart12" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues12 = ['Male ({{$winning_elec17}})', 'Female ({{$winning_elec18}})']; // Labels for the bars
    const yValues12 = [{{$winning_elec17}}, {{$winning_elec18}}]; // Values for the bars

    const barColors12 = "#00cc99";

    new Chart("myChart12", {
        type: "horizontalBar",
        data: {
            labels: xValues12,
            datasets: [{
                backgroundColor: barColors12,
                data: yValues12
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false },
            scales: {
        xAxes: [{
          ticks: {
            beginAtZero: true // Ensure the y-axis starts at zero
          }
        }]
      }
        }
    });
  </script>
    </div>
</div>
</div>

</div>


<script>
function openPosition(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>

<script>
function openCity5(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent5");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks5");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen5").click();
</script>
   
</body>
</html>