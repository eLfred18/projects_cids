<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
	<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    		margin-left: auto;
    		margin-right: auto;

		}
		#emp td,#emp th{
			border: 1px solid #ddd;
			padding: 8px;
		}
		#emp tr:nth-child(even){
            background-color: #e4f0f0;

		}
		#emp th{
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: left;
			background-color: #4CAF50;
			color: #fff;
		}
	</style>
</head>
<body>
<p id="emp"> <p>
<div id="emp">

</div>

<div id="emp" style="display: flex;">
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the left column -->
            <p id="emp">Region 1: Alaminos City (2013)</p>

<table id="emp">
<thead>
<tr>
    <th>Candidates</th>
    <th>Party</th>
    <th>Votes</th>
    
</tr>
</thead>
<tbody>
@foreach($employees->where('city', "Alaminos City") as $emp)
   <tr>
    <td>{{$emp->candidate}}</td>
    <td>{{$emp->party}}</td>
    <td>{{$emp->votes}}</td>

   </tr>
@endforeach
</tbody>
</table>


        </div>
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the right column -->
        
<canvas id="myChart" style="width:100%;max-width:90%"></canvas>
<script>
    const xValues = [];
    const yValues = [];

    @foreach($employees->where('city', "Alaminos City") as $emp)
        xValues.push("{{$emp->candidate}} ({{$emp->party}})");
        yValues.push({{$emp->votes}});
    @endforeach

    const barColors = "#00cc99";

    new Chart("myChart", {
        type: "horizontalBar",
        data: {
            labels: xValues,
            datasets: [{
                backgroundColor: barColors,
                data: yValues
            }]
        },
        options: {
            legend: { display: false },
            title: {
                display: false,
                text: "Region 1: Alaminos City (2013)"
            }
        }
    });
</script>
        </div>
    </div>



	

</body>
</html>