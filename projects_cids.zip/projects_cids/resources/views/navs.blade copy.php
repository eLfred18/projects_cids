<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
	<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    		margin-left: auto;
    		margin-right: auto;

		}
		#emp td,#emp th{
			border: 0px;
			padding: 20px;
      vertical-align:top;
      font-size: 13px;
		}
		
		#emp th{
			padding-top: 12px;
			padding-bottom: 12px;
			text-align: left;
			background-color: #4CAF50;
			color: #fff;
		}
        /* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

/* Style the tab content */
.tabcontent {
  animation: fadeEffect 1s;
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
.tabcontent2 {
  animation: fadeEffect 1s;
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
.tab select.split {
  float: right;
  background-color: #04AA6D;
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}
	</style>
</head>
<body>


<div id="emp" style="display: flex;">
        <div style="flex: 1; padding: 20px;">
            <!-- Content for the right column -->
<strong id="emp">Gubernatorial Elections</strong>          
<div class="tab">
  <button class="tablinks2" onclick="openCity2(event, 'Luzon2')" id="defaultOpen2">Luzon</button>
  <button class="tablinks2" onclick="openCity2(event, 'Visayas2')">Visayas</button>
  <button class="tablinks2" onclick="openCity2(event, 'Mindanao2')">Mindanao</button>
  <form>
  <select class="split">
  @foreach($navs as $emp)
  <option value="{{$emp->year}}">&nbsp;{{$emp->year}}</option>
  @endforeach
  </select>
</div> 

<div id="Luzon2" class="tabcontent2">
<table>
<tbody>
<tr>
    <td><strong>Ilocos Region</strong><br>
    @foreach($navs2->where('rid', "Ilocos Region")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach
    <br>
    <strong>Cagayan Valley</strong><br>
    @foreach($navs2->where('rid', "Cagayan Valley")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach<br>
    <strong>CAR</strong><br>
    @foreach($navs2->where('rid', "CAR")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach 
    </td>
    <td><strong>Central Luzon</strong><br>
    @foreach($navs2->where('rid', "Central Luzon")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach <br>       
    <strong>CALABARZON</strong><br>
    @foreach($navs2->where('rid', "CALABARZON")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>MIMAROPA</strong><br>
    @foreach($navs2->where('rid', "MIMAROPA")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach<br>
    <strong>Bicol Region</strong><br>
    @foreach($navs2->where('rid', "Bicol Region")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach 
  </td>
	</tr>
</tbody>
</table>
</div>


<div id="Visayas2" class="tabcontent2">
<table>
<tbody>
   <tr>
    <td><strong>Western Visayas</strong><br>
    @foreach($navs2->where('rid', "Western Visayas")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Central Visayas</strong><br>
    @foreach($navs2->where('rid', "Central Visayas")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Eastern Visayas")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    	</tr>
</tbody>
</table>
</div>

<div id="Mindanao2" class="tabcontent2">
<table>
<tbody>
   <tr>
    <td><strong>Zamboanga Peninsula</strong><br>
    @foreach($navs2->where('rid', "Zamboanga Peninsula")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>Northern Mindanao</strong><br>
    @foreach($navs2->where('rid', "Northern Mindanao")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Davao Region")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>SOCCSKSARGEN</strong><br>
    @foreach($navs2->where('rid', "SOCCSKSARGEN")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>CARAGA</strong><br>
    @foreach($navs2->where('rid', "CARAGA")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>BARMM</strong><br>
    @foreach($navs2->where('rid', "BARMM")->where('position',"Gubernatorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
	</tr> </form>
</tbody>
</table>
</div>
</div>


<div style="flex: 1; padding: 20px;">
  <!-- Content for the right column -->

<strong id="emp">Mayorial Elections</strong> 
<div class="tab">
  <button class="tablinks" onclick="openCity(event, 'Luzon')" id="defaultOpen">Luzon</button>
  <button class="tablinks" onclick="openCity(event, 'NCR')">NCR</button>
  <button class="tablinks" onclick="openCity(event, 'Visayas')">Visayas</button>
  <button class="tablinks" onclick="openCity(event, 'Mindanao')">Mindanao</button>
  <form>
  <select class="split">
  @foreach($navs as $emp)
  <option value="{{$emp->year}}">&nbsp;{{$emp->year}}</option>
  @endforeach
  </select>
</div> 

<div id="Luzon" class="tabcontent">
<table>
<tbody>
<tr>
    <td><strong>Ilocos Region</strong><br>
    @foreach($navs2->where('rid', "Ilocos Region")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach
    <br>
    <strong>Cagayan Valley</strong><br>
    @foreach($navs2->where('rid', "Cagayan Valley")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach<br>
    <strong>CAR</strong><br>
    @foreach($navs2->where('rid', "CAR")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach 
    </td>
    <td><strong>Central Luzon</strong><br>
    @foreach($navs2->where('rid', "Central Luzon")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach        
    </td>
    <td><strong>CALABARZON</strong><br>
    @foreach($navs2->where('rid', "CALABARZON")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>MIMAROPA</strong><br>
    @foreach($navs2->where('rid', "MIMAROPA")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach<br>
    <strong>Bicol Region</strong><br>
    @foreach($navs2->where('rid', "Bicol Region")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach 
  </td>
	</tr>
</tbody>
</table>
</div>

<div id="NCR" class="tabcontent">
<table>
<tbody>
    <td>
    <td><strong>NCR</strong><br>
    @foreach($navs2->where('rid', "NCR") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
</td>
</tbody>
</table>
</div>

<div id="Visayas" class="tabcontent">
<table>
<tbody>
   <tr>
    <td><strong>Western Visayas</strong><br>
    @foreach($navs2->where('rid', "Western Visayas")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Central Visayas</strong><br>
    @foreach($navs2->where('rid', "Central Visayas")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Eastern Visayas")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    	</tr>
</tbody>
</table>
</div>

<div id="Mindanao" class="tabcontent">
<table>
<tbody>
   <tr>
    <td><strong>Zamboanga Peninsula</strong><br>
    @foreach($navs2->where('rid', "Zamboanga Peninsula")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>Northern Mindanao</strong><br>
    @foreach($navs2->where('rid', "Northern Mindanao")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Davao Region")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>SOCCSKSARGEN</strong><br>
    @foreach($navs2->where('rid', "SOCCSKSARGEN")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
    <td><strong>CARAGA</strong><br>
    @foreach($navs2->where('rid', "CARAGA")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  <br>
    <strong>BARMM</strong><br>
    @foreach($navs2->where('rid', "BARMM")->where('position',"Mayorial") as $emps)
    <p>&nbsp;&nbsp;&nbsp;&nbsp;{{$emps->city}}</p>
    @endforeach  </td>
	</tr> </form>
</tbody>
</table>
</div>

</div>
</div>
	
<script>
function openCity(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script>
function openCity2(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent2");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks2");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen2").click();
</script>

</body>
</html>