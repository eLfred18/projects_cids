<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Election Dataset</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
* {box-sizing: border-box}
body {font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 15%;
  height: 100%; 
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 16px 15px;
  width: 100%;
  height: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #ddd;
}

/* Style the tab content */
.tabcontent {
  float: left;
  padding: 16px 16px;
  border: 1px solid #ccc;
  width: 85%;
  height: 100%;
}
</style>

<style >
		#emp{
			font-family: Arial,Helvetica,sans-serif;
			border-collapse: collapse;
			width: 90%;
    	margin-left: auto;
    	margin-right: auto;

		}
		#emp td,#emp th{
			border: 0px;
			padding: 10px,10px;
      vertical-align:top;
      font-size: 14px;
      text-align: left;
		}
        /* Style the tab */
.tab2,.tab3 {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab2 button,.tab3 button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}

/* Change background color of buttons on hover */
.tab3 button:hover {
  background-color: #ccc;
}

/* Create an active/current tablink class */
.tab3 button.active {
  background-color: #ccc;
}

.tabcontent3 {
  animation: fadeEffect 1s;
  display: none;
  padding: 12px 18px;
  border: 1px solid #ccc;
  border-top: none;
}
@keyframes fadeEffect {
  from {opacity: 0;}
  to {opacity: 1;}
}
.tab3 select.split {
  float: right;
  background-color: #04AA6D;
  background-color: inherit;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 8px 10px;
  transition: 0.3s;
  font-size: 15px;
}
	</style>
    <style>
  * {box-sizing: border-box;}

  body {
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
  }

  .topnav {
    overflow: hidden;
    background-color: #E1B355;
  }

  .topnav a {
    float: left;
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    font-size: 17px;
  }

  .topnav a:hover {
    background-color: #E1B355;
    color: white;
  }

  .topnav a.active {
    background-color: #2196F3;
    color: white;
  }

  .topnav .search-container {
    float: right;
  }

  .topnav input[type=text] {
    padding: 6px;
    margin-top: 8px;
    font-size: 17px;
    border: none;
  }

  .topnav .search-container button {
    float: right;
    padding: 6px 10px;
    margin-top: 8px;
    margin-right: 16px;
    background: #ddd;
    font-size: 17px;
    border: none;
    cursor: pointer;
  }

  .topnav .search-container button:hover {
    background: #ccc;
  }

  @media screen and (max-width: 600px) {
    .topnav .search-container {
      float: none;
    }
    .topnav a, .topnav input[type=text], .topnav .search-container button {
      float: none;
      display: block;
      text-align: left;
      width: 100%;
      margin: 0;
      padding: 14px;
    }
    .topnav input[type=text] {
      border: 1px solid #ccc;  
    }
  }
  </style>
</head>
<body>

<strong id="emp">Vice Gubernatorial Elections {{request('year')}}</strong>          
<div class="tab3">
  <button class="tablinks3" onclick="openCity3(event, 'Luzon3')" id="defaultOpen3">Luzon</button>
  <button class="tablinks3" onclick="openCity3(event, 'Visayas3')">Visayas</button>
  <button class="tablinks3" onclick="openCity3(event, 'Mindanao3')">Mindanao</button>
 
</div> 

<div id="Luzon3" class="tabcontent3">
<table id="emp">
<tbody>
<tr>
    <td><strong>Ilocos Region</strong><br>
    @foreach($navs2->where('rid', "Ilocos Region")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>Cagayan Valley</strong><br>
    @foreach($navs2->where('rid', "Cagayan Valley")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>CAR</strong><br>
    @foreach($navs2->where('rid', "CAR")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
    <br></td>
    <td><strong>Central Luzon</strong><br>
    @foreach($navs2->where('rid', "Central Luzon")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
    <br></td>      
    <td><strong>CALABARZON</strong><br>
    @foreach($navs2->where('rid', "CALABARZON")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>
    <td><strong>MIMAROPA</strong><br>
    @foreach($navs2->where('rid', "MIMAROPA")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach
    <br></td>      
    <td><strong>Bicol Region</strong><br>
    @foreach($navs2->where('rid', "Bicol Region")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach 
  </td>
	</tr>
</tbody>
</table>

  </div>

</div>


<div id="Visayas3" class="tabcontent3">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Western Visayas</strong><br>
    @foreach($navs2->where('rid', "Western Visayas")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    <td><strong>Central Visayas</strong><br>
    @foreach($navs2->where('rid', "Central Visayas")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    <td><strong>Eastern Visayas</strong><br>
    @foreach($navs2->where('rid', "Eastern Visayas")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  </td>
    	</tr>
</tbody>
</table>
</div>

<div id="Mindanao3" class="tabcontent3">
<table  id="emp">
<tbody>
   <tr>
    <td><strong>Zamboanga Peninsula</strong><br>
    @foreach($navs2->where('rid', "Zamboanga Peninsula")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>Northern Mindanao</strong><br>
    @foreach($navs2->where('rid', "Northern Mindanao")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>Davao Region</strong><br>
    @foreach($navs2->where('rid', "Davao Region")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>SOCCSKSARGEN</strong><br>
    @foreach($navs2->where('rid', "SOCCSKSARGEN")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>CARAGA</strong><br>
    @foreach($navs2->where('rid', "CARAGA")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
    <td><strong>BARMM</strong><br>
    @foreach($navs2->where('rid', "BARMM")->where('position',"Vice Gubernatorial") as $emps)
     <p>&nbsp;&nbsp;&nbsp;&nbsp;<a href="{{ route('election', ['rid' => $emps->rid,'city' => $emps->city, 'year' => request('year'), 'position' => 'Vice Gubernatorial']) }}">{{$emps->city}}</a></p>
    @endforeach  <br></td>
	</tr>
</tbody>
</table>
</div>
<div class="grid grid-cols-1 md:grid-cols-2">
<div class="p-6">
  <small>Luzon Gender Demographics of Candidates </small>
  <canvas id="myChart13" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues13 = ['Male ({{$elec7}})', 'Female ({{$elec8}})']; // Labels for the bars
    const yValues13 = [{{$elec7}}, {{$elec8}}]; // Values for the bars

    const barColors13 = "#00cc99";

    new Chart("myChart13", {
        type: "horizontalBar",
        data: {
            labels: xValues13,
            datasets: [{
                backgroundColor: barColors13,
                data: yValues13
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Luzon Gender Demographics of Winning Candidates </small>
  <canvas id="myChart14" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues14 = ['Male ({{$winning_elec7}})', 'Female ({{$winning_elec8}})']; // Labels for the bars
    const yValues14 = [{{$winning_elec7}}, {{$winning_elec8}}];

    const barColors14 = "#00cc99";

    new Chart("myChart14", {
        type: "horizontalBar",
        data: {
            labels: xValues14,
            datasets: [{
                backgroundColor: barColors14,
                data: yValues14
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Visayas Gender Demographics of Candidates </small>
  <canvas id="myChart15" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues15 = ['Male ({{$elec9}})', 'Female ({{$elec10}})']; // Labels for the bars
    const yValues15 = [{{$elec9}}, {{$elec10}}]; // Values for the bars

    const barColors15 = "#00cc99";

    new Chart("myChart15", {
        type: "horizontalBar",
        data: {
            labels: xValues15,
            datasets: [{
                backgroundColor: barColors15,
                data: yValues15
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Visayas Gender Demographics of Winning Candidates </small>
  <canvas id="myChart16" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues16 = ['Male ({{$winning_elec9}})', 'Female ({{$winning_elec10}})']; // Labels for the bars
    const yValues16 = [{{$winning_elec9}}, {{$winning_elec10}}];

    const barColors16 = "#00cc99";

    new Chart("myChart16", {
        type: "horizontalBar",
        data: {
            labels: xValues16,
            datasets: [{
                backgroundColor: barColors16,
                data: yValues16
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Mindanao Gender Demographics of Candidates </small>
  <canvas id="myChart17" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues17 = ['Male ({{$elec11}})', 'Female ({{$elec12}})']; // Labels for the bars
    const yValues17 = [{{$elec11}}, {{$elec12}}]; // Values for the bars

    const barColors17 = "#00cc99";

    new Chart("myChart17", {
        type: "horizontalBar",
        data: {
            labels: xValues17,
            datasets: [{
                backgroundColor: barColors17,
                data: yValues17
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
</div>

<div class="p-6">
  <small>Mindanao Gender Demographics of Winning Candidates </small>
  <canvas id="myChart18" style="width:90%;max-width:90%;height:50%"></canvas>
  <script>
    const xValues18 = ['Male ({{$winning_elec11}})', 'Female ({{$winning_elec12}})']; // Labels for the bars
    const yValues18 = [{{$winning_elec11}}, {{$winning_elec12}}]; // Values for the bars

    const barColors18 = "#00cc99";

    new Chart("myChart18", {
        type: "horizontalBar",
        data: {
            labels: xValues18,
            datasets: [{
                backgroundColor: barColors18,
                data: yValues18
            }]
        },
        options: {
            plugins: {
                datalabels: {
                    anchor: 'end',
                    align: 'end',
                    formatter: function(value, context) {
                        return value; // Display the value as label
                    }
                }
            },
            legend: { display: false },
            title: { display: false }
        }
    });
  </script>
    </div>
</div>
</div>


<script>
function openPosition(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
<script>
function openCity3(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent3");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks3");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen3").click();
</script>

<script>
function openCity3(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent3");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks3");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen3").click();
</script>
   
</body>
</html>