<?php

namespace App\Imports;

use App\Models\Performance;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class PerformanceImport implements ToModel,WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Performance([

            'rid'=>$row['rid'],
            'city'=>$row['city'],
            'elecyr'=>$row['elecyr'],
            'year'=>$row['year'],
            'candidate'=>$row['candidate'],
            'votes'=>$row['votes'],
            'total'=>$row['total'],
            'no_cand'=>$row['no_cand'],
            'income'=>$row['income'],
            'localsources'=>$row['localsources'],
            'ira'=>$row['ira'],
            'tax'=>$row['tax'],
            'externalsources'=>$row['externalsources'],
                        
            'govexpenses'=>$row['govexpenses'],
            'pubwelfareexpenses'=>$row['pubwelfareexpenses'],
            'educexpenses'=>$row['educexpenses'],
            'healthexpenses'=>$row['healthexpenses'],
            'laborexpenses'=>$row['laborexpenses'],
            'housingexpenses'=>$row['housingexpenses'],
            'socservexpenses'=>$row['socservexpenses'],
            'econdevexpenses'=>$row['econdevexpenses'],
            'totalexpenses'=>$row['totalexpenses']
            
        ]);
    }
}
