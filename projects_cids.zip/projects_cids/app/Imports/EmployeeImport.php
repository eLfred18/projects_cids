<?php

namespace App\Imports;

use App\Models\Employee;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class EmployeeImport implements ToModel,WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Employee([

            'rid'=>$row['rid'],
            'city'=>$row['city'],
            'candidate'=>$row['candidate'],
            'gender'=>$row['gender'],
            'party'=>$row['party'],
            'votes'=>$row['votes'],
            'total'=>$row['total'],
            'won'=>$row['won'],
            'year'=>$row['year']
            
            
        ]);
    }
}
