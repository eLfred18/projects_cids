<?php

namespace App\Exports;

use App\Models\Election;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ElectionExport implements FromCollection,WithHeadings
{
	public function headings():array{
		return[
         
         'Region',
         'City/Province',
         'Candidate',
         'Gender',
         'Party',
         'Votes',
         'Total Votes',
         'Winner',
         'Election Year',
         'Position'
		];
	}
    
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //return Election::all();
        return collect(Election::getElection());
    }
}
