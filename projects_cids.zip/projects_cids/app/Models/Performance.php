<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Performance extends Model
{
    use HasFactory;

    protected $table="performance";

    protected $fillable=['rid','city','elecyr','year','candidate','votes','total','no_cand','income','localsources','ira','tax','externalsources','govexpenses','pubwelfareexpenses','educexpenses','healthexpenses','laborexpenses','housingexpenses','socservexpenses','econdevexpenses','totalexpenses'];

    public static function getElection()
    {
    	$records=DB::table('performance')->select('rid','city','elecyr','year','candidate','votes','total','no_cand','income','localsources','ira','tax','externalsources','govexpenses','pubwelfareexpenses','educexpenses','healthexpenses','laborexpenses','housingexpenses','socservexpenses','econdevexpenses','totalexpenses')->get()->toArray();
    	return $records;
    }
}
