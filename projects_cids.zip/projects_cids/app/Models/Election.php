<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Election extends Model
{
    use HasFactory;

    protected $table="election";

    protected $fillable=['rid','city','candidate','gender','party','votes','total','won','year','position'];

    public static function getElection()
    {
    	$records=DB::table('election')->select('rid','city','candidate','gender','party','votes','total','won','year','position')->get()->toArray();
    	return $records;
    }
}
