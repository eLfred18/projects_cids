<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Election;
use App\Models\Performance;
use Illuminate\Support\Facades\DB;
use PDF;

class ElecsController extends Controller
{
    //
    public function getAllElection2()
    {
    	$election=Election::all();
    	return view('election',compact('election'));
    }

    public function getAllElection(Request $request)
    {
        $rid = $request->input('rid'); 
        $city = $request->input('city');
        $year = $request->input('year');
        $position = $request->input('position');
        $election = Election::all();
        $performance = Performance::all()->sortBy('year'); 
        return view('election', compact('election','performance'));
    }
    

public function getCandidate()
{
    $search= request()->input('search');
    $candi = Election::where('candidate', 'like', '%' . $search . '%')
    ->orderBy('id')
    ->get();
    return view('searchResults',compact('candi'));
}


public function getCandidate2()
{
    $candi2 = Election::orderBy('id')
    ->get();
    return view('candidate',compact('candi2'));
}

    public function getYear()
    {
    	$election=Election::distinct()->orderBy('year')->get(['year']);
    	return view('index',compact('election'));
    }
    public function getNav()
    {
    	$navs = Election::distinct()->orderBy('year')->get(['year']);
    	$navs2 = Election::distinct()->get(['rid','city','position']);

        $elec1= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $elec2= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $winning_elec1= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec2= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();
        $elec3= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $elec4= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $elec5= Election::where('gender', 1)
                  ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $elec6= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->count();
        $winning_elec3= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec4= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec5= Election::where('gender', 1)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec6= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Gubernatorial')
                  ->where('won',1)
                  ->count();

        $elec7= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $elec8= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $winning_elec7= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec8= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();
        $elec9= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $elec10= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $elec11= Election::where('gender', 1)
                  ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $elec12= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->count();
        $winning_elec9= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec10= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec11= Election::where('gender', 1)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();
        $winning_elec12= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Gubernatorial')
                  ->where('won',1)
                  ->count();


        $elec13= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec14= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec15= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec16= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec17= Election::where('gender', 1)
                  ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec18= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $winning_elec13= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec14= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec15= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec16= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec17= Election::where('gender', 1)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec18= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();

        $elec19= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $elec20= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $elec21= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $elec22= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $elec23= Election::where('gender', 1)
                  ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $elec24= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->count();
        $winning_elec19= Election::where('gender', 1)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec20= Election::where('gender', 0)
                  ->whereIn('rid', ['Ilocos Region','Cagayan Valley','CAR','Central Luzon','CALABARZON','MIMAROPA','Bicol Region'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec21= Election::where('gender', 1)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec22= Election::where('gender', 0)
                  ->whereIn('rid', ['Western Visayas','Central Visayas','Eastern Visayas'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec23= Election::where('gender', 1)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec24= Election::where('gender', 0)
        ->whereIn('rid', ['Zamboanga Peninsula','Northern Mindanao','Davao Region','SOCCSKSARGEN','CARAGA','BARMM'])
                  ->where('year',request('year'))
                  ->where('position','Vice Mayorial')
                  ->where('won',1)
                  ->count();
        $elec25= Election::where('gender', 1)
        ->whereIn('rid', ['NCR'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $elec26= Election::where('gender', 0)
        ->whereIn('rid', ['NCR'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->count();
        $winning_elec25= Election::where('gender', 1)
        ->whereIn('rid', ['NCR'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
        $winning_elec26= Election::where('gender', 0)
        ->whereIn('rid', ['NCR'])
                  ->where('year',request('year'))
                  ->where('position','Mayorial')
                  ->where('won',1)
                  ->count();
    	return view('navs',compact('navs','navs2','elec1','elec2','elec3','elec4','elec5','elec6','elec7','elec8','elec9','elec10','elec11','elec12',
        'elec13','elec14','elec15','elec16','elec17','elec18','elec19','elec20','elec21','elec22','elec23','elec24','elec25','elec26',
        'winning_elec1','winning_elec2','winning_elec3','winning_elec4','winning_elec5','winning_elec6','winning_elec7','winning_elec8',
        'winning_elec9','winning_elec10','winning_elec11','winning_elec12','winning_elec13','winning_elec14','winning_elec15','winning_elec16',
        'winning_elec17','winning_elec18','winning_elec19','winning_elec20','winning_elec21','winning_elec22','winning_elec23','winning_elec24',
        'winning_elec25','winning_elec26'));
    }

    public function getNav2()
{
    // Initialize arrays to hold regions and positions
    $regions = [
        'Luzon' => ['Ilocos Region', 'Cagayan Valley', 'CAR', 'Central Luzon', 'CALABARZON', 'MIMAROPA', 'Bicol Region'],
        'Visayas' => ['Western Visayas', 'Central Visayas', 'Eastern Visayas'],
        'Mindanao' => ['Zamboanga Peninsula', 'Northern Mindanao', 'Davao Region', 'SOCCSKSARGEN', 'CARAGA', 'BARMM'],
        'NCR' => ['NCR']
    ];

    $positions = ['Gubernatorial', 'Vice Gubernatorial', 'Mayorial', 'Vice Mayorial'];

    $year = request('year');

    $navData = [];

    // Iterate over regions and positions to calculate counts
    foreach ($regions as $regionKey => $regionValues) {
        foreach ($positions as $position) {
            foreach ([1, 0] as $gender) {
                $countKey = "elec_{$regionKey}_{$position}_{$gender}";
                $winningCountKey = "winning_elec_{$regionKey}_{$position}_{$gender}";

                // Counting elections
                $navData[$countKey] = Election::where('gender', $gender)
                    ->whereIn('rid', $regionValues)
                    ->where('year', $year)
                    ->where('position', $position)
                    ->count();

                // Counting winning elections
                $navData[$winningCountKey] = Election::where('gender', $gender)
                    ->whereIn('rid', $regionValues)
                    ->where('year', $year)
                    ->where('position', $position)
                    ->where('won', 1)
                    ->count();
            }
        }
    }

    $navs = Election::distinct()->orderBy('year')->get(['year']);
    $navs2 = Election::distinct()->get(['rid', 'city', 'position']);

    return view('navs', compact('navs', 'navs2', 'navData'));
}

    
    public function handleYear(Request $request)
    {
        $year = $request->input('year');
        return $year;
    }

    

    public function downloadPDF()
    {
    	$election=Election::all();
    	$pdf=PDF::loadview('election',compact('election'));
    	return $pdf->download('elections.pdf');
    }
    
}
