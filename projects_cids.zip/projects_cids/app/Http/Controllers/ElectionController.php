<?php

namespace App\Http\Controllers;

use App\Models\Election;
use App\Models\Performance;
use Illuminate\Http\Request;
use App\Exports\ElectionExport;
use Excel;
use App\Imports\ElectionImport;
use App\Imports\PerformanceImport;

class ElectionController extends Controller
{
    public function exportIntoExcel()
    {
        return Excel::download(new ElectionExport,'election_dataset.xlsx');
    }

    public function exportIntoCSV()
    {
        return Excel::download(new ElectionExport,'electionlist.csv');
    }

    public function importForm(){
        return view('import-form');
    }

    public function import(Request $request)
    {
        Excel::import(new ElectionImport,$request->file);
        return "Record are imported successfully!";

    }
    public function importPerformance(){
        return view('import-performance');
    }

    public function import2(Request $request)
    {
        Excel::import(new PerformanceImport,$request->file);
        return "Record are imported successfully!";

    }
}
