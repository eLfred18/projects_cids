<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateElectionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('election', function (Blueprint $table) {
            $table->id();
            $table->string('rid');
            $table->string('city');
            $table->string('position');
            $table->string('candidate');
            $table->integer('gender');
            $table->string('party')->nullable();
            $table->integer('votes');
            $table->integer('total');
            $table->integer('won');
            $table->integer('year');
            $table->string('updated_at');
            $table->string('created_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('election');
    }
}
