<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePerformanceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('performance', function (Blueprint $table) {
            $table->id();
            $table->string('rid');
            $table->string('city');
            $table->integer('elecyr');
            $table->integer('year');
            $table->string('candidate');
            $table->integer('votes');
            $table->integer('total');
            $table->integer('no_cand')->nullable();
            $table->decimal('income',32,2)->nullable();
            $table->decimal('localsources',32,2)->nullable();
            $table->decimal('ira',32,2)->nullable();
            $table->decimal('tax',32,2)->nullable();
            $table->decimal('externalsources',32,2)->nullable();

            $table->decimal('govexpenses',32,2)->nullable();
            $table->decimal('pubwelfareexpenses',32,2)->nullable();
            $table->decimal('educexpenses',32,2)->nullable();
            $table->decimal('healthexpenses',32,2)->nullable();
            $table->decimal('laborexpenses',32,2)->nullable();
            $table->decimal('housingexpenses',32,2)->nullable();
            $table->decimal('socservexpenses',32,2)->nullable();
            $table->decimal('econdevexpenses',32,2)->nullable();
            $table->decimal('totalexpenses',32,2);
            $table->string('updated_at');
            $table->string('created_at');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('performance');
    }
}
