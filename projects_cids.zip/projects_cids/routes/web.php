<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EmployeeController;
use App\Http\Controllers\EmpController;
use App\Http\Controllers\ElecsController;
use App\Http\Controllers\ElectionController;
use App\Http\Controllers\NavController;
use App\Http\Controllers\Controller;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[ElecsController::class,'getYear'], function () {
    return view('index');
});
//export
Route::get('/export-excel',[EmployeeController::class,'exportIntoExcel']);
Route::get('/export',[ElectionController::class,'exportIntoExcel']);
Route::get('/export-csv',[EmployeeController::class,'exportIntoCSV']);
Route::get('/download-pdf',[EmpController::class,'downloadPDF']);

//elecs Controller 
Route::get('/election',[ElecsController::class,'getAllElection'])->name('election');

Route::get('/searchResults',[ElecsController::class,'getCandidate'])->name('searchResults');
Route::get('/candidate',[ElecsController::class,'getCandidate2'])->name('candi2');

Route::get('/navigation',[ElecsController::class,'getNav']);

Route::get('/index',[ElecsController::class,'getYear']);

Route::get('/import-form',[ElectionController::class,'importForm']);
Route::get('/import-performance',[ElectionController::class,'importPerformance']);
Route::post('/import2',[ElectionController::class,'import2'])->name('performance.import');
Route::post('/import',[ElectionController::class,'import'])->name('election.import');


